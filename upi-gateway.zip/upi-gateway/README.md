# Free UPI Gateway (self-hosted)

A zero-fee tool to collect UPI payments into **your own VPA**: create orders via API, show a QR/intent checkout, auto-confirm from bank credit alerts, receive signed callbacks, and manage everything in a dashboard.

> **Important:** This is not an RBI-licensed Payment Aggregator. It never touches money; payments go straight from customer to your UPI ID. Fine for your own small business. If you collect for *other* merchants, you need a licensed PA. Confirmation relies on your bank alerts or manual review, so there is no bank-grade guarantee.

## Workflow
1. Your site calls `POST /api/orders` (header `x-api-key`) with `{amount, note, callback_url}` and gets a `pay_url`.
2. Customer opens `pay_url`, scans the QR or taps *Open UPI app*. Each order gets a unique paise amount (e.g. ₹100.37).
3. Confirmation, whichever happens first:
   - **Auto:** your phone's SMS forwarder posts the bank credit SMS to `POST /api/bank-webhook` (header `x-webhook-secret`, body `{"text": "<sms>"}`). The amount is matched to the order.
   - **UTR:** customer enters the 12-digit UTR, order goes to *review*, you approve in the dashboard.
   - **Manual:** mark paid in the dashboard.
4. Gateway POSTs `{order_id,status,amount,utr,paid_at}` to your `callback_url` with `X-Signature` = HMAC-SHA256(body, API_KEY). Verify it before fulfilling.

## Run
```bash
cp .env.example .env   # edit values
npm install && npm test
export $(grep -v '^#' .env | xargs) && npm start
# dashboard: http://localhost:3000/admin.html  (sign in with ADMIN_TOKEN)
```
Docker: `docker build -t upi-gateway . && docker run -p 3000:3000 --env-file .env -v $PWD/data:/app/data upi-gateway`

Free hosting: Render, Railway or Fly.io (keep `/app/data` on a persistent volume). Use HTTPS in production.

## SMS forwarder setup (Android)
Use an app like "SMS Forwarder" or Tasker: filter SMS from your bank containing "credited", HTTP POST to `https://YOUR_HOST/api/bank-webhook` with header `x-webhook-secret` and JSON body `{"text":"%SMS_BODY%"}`.

## Example
```bash
curl -X POST $BASE/api/orders -H "x-api-key: $API_KEY" -H "Content-Type: application/json" \
  -d '{"amount":499,"note":"Coloring book bundle","callback_url":"https://yoursite.com/upi-callback"}'
```
Verify callback (Node): `crypto.createHmac('sha256', API_KEY).update(rawBody).digest('hex') === req.get('X-Signature')`

## Hardening ideas
Add rate limiting, move secrets to a vault, restrict `/admin.html` by IP, add a bank-alert email parser, switch to Postgres for scale.

MIT licensed.
