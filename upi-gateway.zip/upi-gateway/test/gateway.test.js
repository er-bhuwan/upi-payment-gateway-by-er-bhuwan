process.env.DB_FILE = ':memory:'; process.env.API_KEY = 'k'; process.env.WEBHOOK_SECRET = 'h'; process.env.ADMIN_TOKEN = 'a';
const test = require('node:test'), assert = require('node:assert');
const app = require('../server');
let srv, url;
test.before(() => new Promise(r => { srv = app.listen(0, () => { url = `http://localhost:${srv.address().port}`; r(); }); }));
test.after(() => srv.close());
const post = (p, b, h = {}) => fetch(url + p, { method: 'POST', headers: { 'Content-Type': 'application/json', ...h }, body: JSON.stringify(b) }).then(r => r.json());

test('order -> bank webhook auto-match -> paid', async () => {
  const c = await post('/api/orders', { amount: 100 }, { 'x-api-key': 'k' });
  assert.ok(c.order_id);
  const pub = await fetch(`${url}/api/orders/${c.order_id}/public`).then(r => r.json());
  const m = await post('/api/bank-webhook', { text: `Rs ${pub.amount} credited via UPI Ref 123456789012` }, { 'x-webhook-secret': 'h' });
  assert.equal(m.matched, true);
  const o = await fetch(`${url}/api/orders/${c.order_id}`, { headers: { 'x-api-key': 'k' } }).then(r => r.json());
  assert.equal(o.status, 'paid');
});
test('rejects bad api key', async () => {
  const r = await fetch(url + '/api/orders', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' });
  assert.equal(r.status, 401);
});
