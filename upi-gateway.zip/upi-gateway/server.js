const express = require('express');
const Database = require('better-sqlite3');
const QRCode = require('qrcode');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const C = {
  vpa: process.env.UPI_VPA || 'test@upi',
  name: process.env.PAYEE_NAME || 'Merchant',
  apiKey: process.env.API_KEY || 'dev-api-key',
  admin: process.env.ADMIN_TOKEN || 'dev-admin',
  hook: process.env.WEBHOOK_SECRET || 'dev-hook',
  base: process.env.BASE_URL || 'http://localhost:3000',
  ttl: Number(process.env.ORDER_TTL_MIN || 15) * 60000,
};

fs.mkdirSync(path.join(__dirname, 'data'), { recursive: true });
const db = new Database(process.env.DB_FILE || path.join(__dirname, 'data', 'gateway.db'));
db.exec(`CREATE TABLE IF NOT EXISTS orders(
  id TEXT PRIMARY KEY, amount_paise INTEGER, pay_paise INTEGER, note TEXT, customer TEXT,
  status TEXT DEFAULT 'pending', utr TEXT, callback_url TEXT, created_at INTEGER, paid_at INTEGER,
  expires_at INTEGER, paid_via TEXT, callback_status TEXT);
  CREATE INDEX IF NOT EXISTS idx_status ON orders(status);`);

const safeEq = (a, b) => {
  const x = Buffer.from(String(a || '')), y = Buffer.from(String(b || ''));
  return x.length === y.length && crypto.timingSafeEqual(x, y);
};
const rupees = p => (p / 100).toFixed(2);
const upiLink = o => `upi://pay?pa=${encodeURIComponent(C.vpa)}&pn=${encodeURIComponent(C.name)}&am=${rupees(o.pay_paise)}&cu=INR&tn=${encodeURIComponent(o.id)}&tr=${encodeURIComponent(o.id)}`;

// Unique paise offset (1-99) so each pending order has a distinct payable amount -> auto-matching.
function uniquePayable(base) {
  for (let i = 0; i < 200; i++) {
    const pay = base + 1 + Math.floor(Math.random() * 99);
    if (!db.prepare("SELECT 1 FROM orders WHERE pay_paise=? AND status='pending'").get(pay)) return pay;
  }
  throw new Error('Too many pending orders at this amount');
}

async function sendCallback(o) {
  if (!o.callback_url) return;
  const body = JSON.stringify({ order_id: o.id, status: o.status, amount: rupees(o.amount_paise), utr: o.utr, paid_at: o.paid_at });
  const sig = crypto.createHmac('sha256', C.apiKey).update(body).digest('hex');
  for (let i = 0; i < 3; i++) {
    try {
      const r = await fetch(o.callback_url, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Signature': sig }, body });
      if (r.ok) return db.prepare('UPDATE orders SET callback_status=? WHERE id=?').run('delivered', o.id);
    } catch (_) {}
    await new Promise(r => setTimeout(r, 2000 * (i + 1)));
  }
  db.prepare('UPDATE orders SET callback_status=? WHERE id=?').run('failed', o.id);
}

function markPaid(id, via, utr) {
  const r = db.prepare("UPDATE orders SET status='paid', paid_at=?, paid_via=?, utr=COALESCE(?,utr) WHERE id=? AND status IN ('pending','review','expired')")
    .run(Date.now(), via, utr || null, id);
  if (r.changes) sendCallback(db.prepare('SELECT * FROM orders WHERE id=?').get(id));
  return r.changes > 0;
}

const app = express();
app.use(express.json({ limit: '50kb' }));
app.use(express.static(path.join(__dirname, 'public')));

const needKey = (req, res, next) => safeEq(req.get('x-api-key'), C.apiKey) ? next() : res.status(401).json({ error: 'bad api key' });
const needAdmin = (req, res, next) => safeEq(req.get('x-admin-token'), C.admin) ? next() : res.status(401).json({ error: 'bad admin token' });

// 1. Merchant creates an order
app.post('/api/orders', needKey, (req, res) => {
  const amount = Math.round(Number(req.body.amount) * 100);
  if (!(amount >= 100 && amount <= 10000000)) return res.status(400).json({ error: 'amount must be 1 to 100000 INR' });
  const cb = req.body.callback_url;
  if (cb && !/^https?:\/\//.test(cb)) return res.status(400).json({ error: 'invalid callback_url' });
  const id = 'ORD' + crypto.randomBytes(5).toString('hex').toUpperCase();
  const now = Date.now();
  db.prepare('INSERT INTO orders(id,amount_paise,pay_paise,note,customer,callback_url,created_at,expires_at) VALUES(?,?,?,?,?,?,?,?)')
    .run(id, amount, uniquePayable(amount), String(req.body.note || '').slice(0, 120), String(req.body.customer || '').slice(0, 80), cb || null, now, now + C.ttl);
  res.json({ order_id: id, pay_url: `${C.base}/pay.html?id=${id}` });
});

// 2. Checkout page data
app.get('/api/orders/:id/public', async (req, res) => {
  const o = db.prepare('SELECT * FROM orders WHERE id=?').get(req.params.id);
  if (!o) return res.status(404).json({ error: 'not found' });
  const link = upiLink(o);
  res.json({ id: o.id, status: o.status, amount: rupees(o.pay_paise), note: o.note, payee: C.name, expires_at: o.expires_at, upi_link: link, qr: await QRCode.toDataURL(link, { margin: 1, width: 320 }) });
});

// 3. Customer submits UTR -> goes to review queue
app.post('/api/orders/:id/utr', (req, res) => {
  const utr = String(req.body.utr || '').trim();
  if (!/^\d{12}$/.test(utr)) return res.status(400).json({ error: 'UTR must be 12 digits' });
  if (db.prepare('SELECT 1 FROM orders WHERE utr=? AND id<>?').get(utr, req.params.id)) return res.status(409).json({ error: 'UTR already used' });
  const r = db.prepare("UPDATE orders SET utr=?, status='review' WHERE id=? AND status IN ('pending','expired')").run(utr, req.params.id);
  res.json({ ok: r.changes > 0 });
});

// 4. Auto-match: SMS-forwarder / bank-alert webhook. Body: { text: "Rs 100.37 credited ... UPI Ref 123456789012" }
app.post('/api/bank-webhook', (req, res) => {
  if (!safeEq(req.get('x-webhook-secret'), C.hook)) return res.status(401).json({ error: 'bad secret' });
  const text = String(req.body.text || req.body.message || '');
  if (!/credit|received|deposit/i.test(text)) return res.json({ matched: false, reason: 'not a credit alert' });
  const amt = text.match(/(?:rs\.?|inr|₹)\s*([\d,]+\.\d{2})/i);
  if (!amt) return res.json({ matched: false, reason: 'amount not found' });
  const paise = Math.round(parseFloat(amt[1].replace(/,/g, '')) * 100);
  const utr = (text.match(/\b(\d{12})\b/) || [])[1];
  const o = db.prepare("SELECT * FROM orders WHERE pay_paise=? AND status IN ('pending','review') ORDER BY created_at DESC").get(paise);
  if (!o) return res.json({ matched: false, reason: 'no open order for amount' });
  markPaid(o.id, 'auto', utr);
  res.json({ matched: true, order_id: o.id });
});

// Merchant polling
app.get('/api/orders/:id', needKey, (req, res) => {
  const o = db.prepare('SELECT id,status,amount_paise,utr,paid_at FROM orders WHERE id=?').get(req.params.id);
  o ? res.json({ ...o, amount: rupees(o.amount_paise) }) : res.status(404).json({ error: 'not found' });
});

// Admin dashboard API
app.get('/api/admin/orders', needAdmin, (req, res) => {
  const s = req.query.status;
  const rows = s ? db.prepare('SELECT * FROM orders WHERE status=? ORDER BY created_at DESC LIMIT 200').all(s)
                 : db.prepare('SELECT * FROM orders ORDER BY created_at DESC LIMIT 200').all();
  res.json(rows.map(o => ({ ...o, amount: rupees(o.amount_paise), pay_amount: rupees(o.pay_paise) })));
});
app.get('/api/admin/stats', needAdmin, (req, res) => {
  const dayStart = new Date().setHours(0, 0, 0, 0);
  const q = (sql, ...a) => db.prepare(sql).get(...a);
  const today = q("SELECT COALESCE(SUM(amount_paise),0) s, COUNT(*) c FROM orders WHERE status='paid' AND paid_at>=?", dayStart);
  const all = q("SELECT COALESCE(SUM(amount_paise),0) s, COUNT(*) c FROM orders WHERE status='paid'");
  const total = q('SELECT COUNT(*) c FROM orders').c;
  const days = db.prepare("SELECT date(paid_at/1000,'unixepoch','localtime') d, SUM(amount_paise) s FROM orders WHERE status='paid' AND paid_at>=? GROUP BY d ORDER BY d").all(Date.now() - 6 * 864e5);
  res.json({
    today: rupees(today.s), today_count: today.c, total: rupees(all.s), paid_count: all.c,
    pending: q("SELECT COUNT(*) c FROM orders WHERE status='pending'").c,
    review: q("SELECT COUNT(*) c FROM orders WHERE status='review'").c,
    conversion: total ? Math.round((all.c / total) * 100) : 0,
    last7: days.map(x => ({ day: x.d, amount: rupees(x.s) })),
  });
});
app.post('/api/admin/orders/:id/mark', needAdmin, (req, res) => {
  const st = req.body.status;
  if (st === 'paid') return res.json({ ok: markPaid(req.params.id, 'manual') });
  if (st === 'rejected' || st === 'expired') {
    const r = db.prepare("UPDATE orders SET status=? WHERE id=? AND status<>'paid'").run(st, req.params.id);
    return res.json({ ok: r.changes > 0 });
  }
  res.status(400).json({ error: 'status must be paid, rejected or expired' });
});
app.post('/api/admin/orders/:id/resend', needAdmin, (req, res) => {
  const o = db.prepare("SELECT * FROM orders WHERE id=? AND status='paid'").get(req.params.id);
  if (!o) return res.status(404).json({ error: 'paid order not found' });
  sendCallback(o); res.json({ ok: true });
});

setInterval(() => db.prepare("UPDATE orders SET status='expired' WHERE status='pending' AND expires_at<?").run(Date.now()), 30000).unref();

module.exports = app;
if (require.main === module) {
  const port = process.env.PORT || 3000;
  app.listen(port, () => console.log(`UPI gateway on :${port}  dashboard: /admin.html`));
}
